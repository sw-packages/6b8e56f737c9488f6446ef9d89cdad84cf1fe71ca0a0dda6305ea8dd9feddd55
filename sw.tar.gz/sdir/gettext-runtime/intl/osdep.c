/* OS dependent parts of libintl.
   Copyright (C) 2001-2002, 2006, 2012, 2015 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as published by
   the Free Software Foundation; either version 2.1 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

#if defined __CYGWIN__ || defined __MINGW32__
# include "intl-exports.c"
#elif defined __EMX__ && !defined __KLIBC__
# include "os2compat.c"
#else
/* Avoid AIX compiler warning.  */
typedef int dummy;
#endif
